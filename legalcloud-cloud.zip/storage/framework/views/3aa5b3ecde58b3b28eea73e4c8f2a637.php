<div class="list-switch">
    <a class="btn btn-soft" href="<?php echo e(route('matricula.listas')); ?>">Elegir lista</a>
    <a class="<?php echo e(($lista ?? '') === 'estudiantes' ? 'btn btn-aqua' : 'btn btn-ghost'); ?>" href="<?php echo e(route('matricula.listas.ver', 'estudiantes')); ?>">Estudiantes</a>
    <a class="<?php echo e(($lista ?? '') === 'cursos' ? 'btn btn-aqua' : 'btn btn-ghost'); ?>" href="<?php echo e(route('matricula.listas.ver', 'cursos')); ?>">Cursos</a>
    <a class="<?php echo e(($lista ?? '') === 'docentes' ? 'btn btn-aqua' : 'btn btn-ghost'); ?>" href="<?php echo e(route('matricula.listas.ver', 'docentes')); ?>">Docentes</a>
    <a class="btn btn-soft" href="<?php echo e(route('matricula.inicio')); ?>">Matricularse</a>
</div>
<?php /**PATH C:\repo\example-app\resources\views/matricula/listas/_nav.blade.php ENDPATH**/ ?>