<?php $__env->startSection('title', 'Personas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-4">
        <div>
            <span class="badge text-bg-secondary mb-2">Listado</span>
            <h1 class="h2 mb-1">Personas registradas</h1>
            <p class="text-secondary mb-0">Busca, edita, elimina o registra capacitaciones.</p>
        </div>
        <a href="<?php echo e(route('personas.crear')); ?>" class="btn btn-primary">Registrar persona</a>
    </div>

    <?php if(session('exito')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('exito')); ?>

        </div>
    <?php endif; ?>

    <form method="GET" action="<?php echo e(route('personas.index')); ?>" class="card border-0 mb-4">
        <div class="card-body">
            <label for="q" class="form-label">Buscador</label>
            <div class="input-group">
                <input
                    type="search"
                    class="form-control"
                    id="q"
                    name="q"
                    value="<?php echo e($busqueda); ?>"
                    placeholder="Nombre, apellidos, correo o teléfono"
                >
                <button type="submit" class="btn btn-outline-primary">Buscar</button>
                <?php if($busqueda !== ''): ?>
                    <a href="<?php echo e(route('personas.index')); ?>" class="btn btn-outline-secondary">Limpiar</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <div class="card border-0">
        <div class="card-body p-0">
            <?php if($personas->isEmpty()): ?>
                <div class="p-4 p-md-5 text-center text-secondary">
                    <?php if($busqueda !== ''): ?>
                        No hay personas que coincidan con “<?php echo e($busqueda); ?>”.
                    <?php else: ?>
                        Aún no hay personas registradas.
                    <?php endif; ?>
                    <div class="mt-3">
                        <?php if($busqueda !== ''): ?>
                            <a href="<?php echo e(route('personas.index')); ?>" class="btn btn-outline-secondary">Ver todas</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('personas.crear')); ?>" class="btn btn-outline-primary">Añadir la primera</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Apellidos</th>
                                <th scope="col">Correo electrónico</th>
                                <th scope="col">Teléfono</th>
                                <th scope="col" class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($persona->id); ?></td>
                                    <td><?php echo e($persona->nombre); ?></td>
                                    <td><?php echo e($persona->apellidos); ?></td>
                                    <td class="text-break"><?php echo e($persona->email); ?></td>
                                    <td><?php echo e($persona->telefono ?: 'No indicado'); ?></td>
                                    <td>
                                        <div class="d-flex justify-content-end gap-2 flex-wrap">
                                            <a href="<?php echo e(route('personas.editar', $persona)); ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                                            <a href="<?php echo e(route('capacitaciones.index', $persona)); ?>" class="btn btn-sm btn-outline-success">Capacitación</a>
                                            <form
                                                method="POST"
                                                action="<?php echo e(route('personas.destroy', $persona)); ?>"
                                                onsubmit="return confirm('¿Eliminar a <?php echo e($persona->nombre); ?> <?php echo e($persona->apellidos); ?>?')"
                                            >
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger">Eliminar</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.crud', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/personas/index.blade.php ENDPATH**/ ?>