<?php $__env->startSection('title', 'Cursos · Lista'); ?>

<?php
    $abrir = (bool) $editandoGrupo || $errors->hasAny(['codigo', 'nombre_curso', 'codigo_grupo', 'docente_id', 'dias', 'inicio', 'fin', 'aula', 'cupo', 'facultad_curso']);
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('matricula.listas._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <article class="card">
        <div class="list-head">
            <h1>Cursos</h1>
            <span class="muted"><?php echo e($grupos->count()); ?></span>
        </div>
        <div class="table-wrap">
            <table class="sheet">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Asignatura</th>
                        <th>Grupo</th>
                        <th>Docente</th>
                        <th>Horario</th>
                        <th>Cupo</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($grupo->asignatura->codigo); ?></td>
                            <td><?php echo e($grupo->asignatura->nombre); ?></td>
                            <td><?php echo e($grupo->codigo_grupo); ?></td>
                            <td><?php echo e($grupo->profesor->nombre ?? $grupo->docente); ?></td>
                            <td><?php echo e($grupo->horario()); ?></td>
                            <td><?php echo e($grupo->tomados); ?>/<?php echo e($grupo->cupo); ?></td>
                            <td><a class="tiny" href="<?php echo e(route('matricula.listas.ver', ['lista' => 'cursos', 'editar' => $grupo->id])); ?>#form-lista">Editar</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="muted">Aún no hay cursos.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <details id="form-lista" class="adder" <?php if($abrir): ?> open <?php endif; ?>>
            <summary><?php echo e($editandoGrupo ? 'Editar curso' : 'Agregar curso'); ?></summary>
            <form method="POST" action="<?php echo e($editandoGrupo ? route('matricula.cursos.actualizar', $editandoGrupo) : route('matricula.cursos.guardar')); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <?php if($editandoGrupo): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="grid-2">
                    <div class="field">
                        <label for="codigo">Código</label>
                        <input id="codigo" name="codigo" value="<?php echo e(old('codigo', $editandoGrupo->asignatura->codigo ?? '')); ?>" required>
                    </div>
                    <div class="field">
                        <label for="codigo_grupo">Grupo</label>
                        <input id="codigo_grupo" name="codigo_grupo" value="<?php echo e(old('codigo_grupo', $editandoGrupo->codigo_grupo ?? '')); ?>" placeholder="SIS401-A" required>
                        <?php $__errorArgs = ['codigo_grupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="field">
                    <label for="nombre_curso">Nombre</label>
                    <input id="nombre_curso" name="nombre_curso" value="<?php echo e(old('nombre_curso', $editandoGrupo->asignatura->nombre ?? '')); ?>" required>
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label for="creditos">Créditos</label>
                        <input id="creditos" name="creditos" type="number" min="1" max="8" value="<?php echo e(old('creditos', $editandoGrupo->asignatura->creditos ?? 3)); ?>" required>
                    </div>
                    <div class="field">
                        <label for="facultad_curso">Facultad</label>
                        <select id="facultad_curso" name="facultad_curso">
                            <?php $__currentLoopData = ['Ingeniería', 'Ciencias', 'Humanidades']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($opcion); ?>" <?php if(old('facultad_curso', $editandoGrupo->asignatura->facultad ?? '') === $opcion): echo 'selected'; endif; ?>><?php echo e($opcion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="field">
                    <label for="prerrequisito">Prerrequisito</label>
                    <input id="prerrequisito" name="prerrequisito" value="<?php echo e(old('prerrequisito', $editandoGrupo->asignatura->prerrequisito ?? 'Ninguno')); ?>">
                </div>
                <div class="field">
                    <label for="docente_id">Docente que toma el curso</label>
                    <select id="docente_id" name="docente_id" required <?php if($docentes->isEmpty()): echo 'disabled'; endif; ?>>
                        <option value=""><?php echo e($docentes->isEmpty() ? 'Agrega un docente primero' : 'Selecciona'); ?></option>
                        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($docente->id); ?>" <?php if((string) old('docente_id', $editandoGrupo->docente_id ?? '') === (string) $docente->id): echo 'selected'; endif; ?>><?php echo e($docente->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['docente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <span class="lbl">Días</span>
                    <div class="days">
                        <?php $__currentLoopData = ['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label>
                                <input type="checkbox" name="dias[]" value="<?php echo e($dia); ?>" <?php if(in_array($dia, old('dias', $editandoGrupo->dias ?? []), true)): echo 'checked'; endif; ?>>
                                <?php echo e($dia); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['dias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label for="inicio">Inicio</label>
                        <input id="inicio" name="inicio" type="time" value="<?php echo e(old('inicio', $editandoGrupo->inicio ?? '08:00')); ?>" required>
                    </div>
                    <div class="field">
                        <label for="fin">Fin</label>
                        <input id="fin" name="fin" type="time" value="<?php echo e(old('fin', $editandoGrupo->fin ?? '10:00')); ?>" required>
                        <?php $__errorArgs = ['fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label for="aula">Aula</label>
                        <input id="aula" name="aula" value="<?php echo e(old('aula', $editandoGrupo->aula ?? '')); ?>" required>
                    </div>
                    <div class="field">
                        <label for="cupo">Cupo</label>
                        <input id="cupo" name="cupo" type="number" min="1" max="80" value="<?php echo e(old('cupo', $editandoGrupo->cupo ?? 30)); ?>" required>
                        <?php $__errorArgs = ['cupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="actions">
                    <?php if($editandoGrupo): ?>
                        <a class="btn btn-soft" href="<?php echo e(route('matricula.listas.ver', 'cursos')); ?>">Cancelar edición</a>
                    <?php endif; ?>
                    <button class="btn btn-ghost" type="submit" <?php if($docentes->isEmpty()): echo 'disabled'; endif; ?>><?php echo e($editandoGrupo ? 'Guardar cambios' : 'Agregar curso'); ?></button>
                </div>
            </form>
        </details>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/listas/cursos.blade.php ENDPATH**/ ?>