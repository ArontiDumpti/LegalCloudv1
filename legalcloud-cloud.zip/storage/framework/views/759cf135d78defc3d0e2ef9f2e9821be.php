<?php $__env->startSection('title', 'Comprobante · Matrícula'); ?>

<?php $__env->startSection('content'); ?>
    <div class="receipt">
        <span class="badge badge-aqua">Paso 4</span>
        <h1 style="margin:0.45rem 0 0.3rem">Matrícula confirmada</h1>
        <p class="muted">Guarda este comprobante. Si cambias de plan, puedes cancelar y volver a elegir.</p>

        <article class="card" style="margin-top:1rem">
            <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap">
                <div>
                    <p class="muted" style="margin:0">Universidad AURA</p>
                    <h2 style="margin:0.2rem 0">Comprobante de matrícula</h2>
                </div>
                <div>
                    <div class="muted">Folio</div>
                    <div class="folio"><?php echo e($matricula->folio); ?></div>
                </div>
            </div>
            <div class="bars" aria-hidden="true"></div>
            <p>
                <strong><?php echo e($estudiante->nombreCompleto()); ?></strong><br>
                <span class="muted"><?php echo e($estudiante->matricula); ?> · <?php echo e($estudiante->programa); ?> · <?php echo e($matricula->periodo); ?></span>
            </p>
            <table>
                <thead>
                    <tr><th>Código</th><th>Asignatura</th><th>Grupo</th><th>Horario</th><th>Créditos</th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $matricula->cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($curso->codigo); ?></td>
                            <td><?php echo e($curso->nombre); ?></td>
                            <td><?php echo e($curso->codigo_grupo); ?></td>
                            <td><?php echo e($curso->horario()); ?></td>
                            <td><?php echo e($curso->creditos); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <p style="margin:1rem 0 0">Total créditos: <strong><?php echo e($matricula->creditos); ?></strong></p>
            <p class="muted"><?php echo e($matricula->confirmada_at->timezone(config('app.timezone'))->format('d/m/Y H:i')); ?></p>
        </article>

        <div class="actions no-print">
            <form method="POST" action="<?php echo e(route('matricula.cancelar')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-soft" type="submit">Cancelar matrícula</button>
            </form>
            <button class="btn btn-aqua" type="button" onclick="window.print()">Imprimir</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/comprobante.blade.php ENDPATH**/ ?>