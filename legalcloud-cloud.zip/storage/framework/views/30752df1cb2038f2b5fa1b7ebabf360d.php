<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $__env->yieldContent('title', 'Matrícula'); ?></title>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=outfit:400,500,600,700|syne:600,700,800" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('css/matricula.css')); ?>">
    </head>
    <body>
        <div class="glow-hot"></div>
        <div class="glow-aqua"></div>
        <div class="rail" aria-hidden="true">
            <span style="background:#000"></span>
            <span style="background:#D88997"></span>
            <span style="background:#FF2D55"></span>
            <span style="background:#1FE5E1"></span>
            <span style="background:#3D717C"></span>
        </div>

        <header class="app">
            <div class="topbar">
                <a class="brand" href="<?php echo e(route('matricula.inicio')); ?>">AURA<span>.</span></a>
                <div class="tools">
                    <div class="period">
                        <?php if(isset($estudiante)): ?>
                            <?php echo e($estudiante->nombreCompleto()); ?> · <?php echo e($estudiante->matricula); ?>

                        <?php else: ?>
                            Periodo 2026-2
                        <?php endif; ?>
                    </div>
                    <?php if(isset($estudiante) && ($paso ?? 1) >= 2): ?>
                        <form method="POST" action="<?php echo e(route('matricula.cancelar')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-soft" type="submit">Cancelar matrícula</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <nav class="steps" aria-label="Etapas">
                <?php $paso = $paso ?? 1; ?>
                <a class="step <?php echo e($paso === 1 ? 'is-on' : ($paso > 1 ? 'is-done' : '')); ?>" href="<?php echo e(route('matricula.inicio')); ?>"><b>1</b><span>Inicio</span></a>
                <a class="step <?php echo e($paso === 2 ? 'is-on' : ($paso > 2 ? 'is-done' : '')); ?>" href="<?php echo e(route('matricula.oferta')); ?>"><b>2</b><span>Cursos</span></a>
                <a class="step <?php echo e($paso === 3 ? 'is-on' : ($paso > 3 ? 'is-done' : '')); ?>" href="<?php echo e(route('matricula.prematricula')); ?>"><b>3</b><span>Horario</span></a>
                <a class="step <?php echo e($paso === 4 ? 'is-on' : ''); ?>" href="<?php echo e(route('matricula.comprobante')); ?>"><b>4</b><span>Comprobante</span></a>
            </nav>
        </header>

        <main class="wrap">
            <?php if(session('ok')): ?>
                <div class="alert alert-ok"><?php echo e(session('ok')); ?></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </body>
</html>
<?php /**PATH C:\repo\example-app\resources\views/layouts/matricula.blade.php ENDPATH**/ ?>