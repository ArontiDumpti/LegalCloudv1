<?php $__env->startSection('title', 'Estudiantes · Lista'); ?>

<?php
    $abrir = (bool) $editandoEstudiante || $errors->hasAny(['est_matricula', 'est_pin', 'nombre', 'apellidos', 'programa', 'facultad', 'semestre']);
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('matricula.listas._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <article class="card">
        <div class="list-head">
            <h1>Estudiantes</h1>
            <span class="muted"><?php echo e($estudiantes->count()); ?></span>
        </div>
        <div class="table-wrap">
            <table class="sheet">
                <thead>
                    <tr>
                        <th>Matrícula</th>
                        <th>Nombre</th>
                        <th>Programa</th>
                        <th>Facultad</th>
                        <th>Semestre</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->matricula); ?></td>
                            <td><?php echo e($item->nombreCompleto()); ?></td>
                            <td><?php echo e($item->programa); ?></td>
                            <td><?php echo e($item->facultad); ?></td>
                            <td><?php echo e($item->semestre); ?>º</td>
                            <td><a class="tiny" href="<?php echo e(route('matricula.listas.ver', ['lista' => 'estudiantes', 'editar' => $item->id])); ?>#form-lista">Editar</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="muted">Aún no hay estudiantes.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <details id="form-lista" class="adder" <?php if($abrir): ?> open <?php endif; ?>>
            <summary><?php echo e($editandoEstudiante ? 'Editar estudiante' : 'Agregar estudiante'); ?></summary>
            <form method="POST" action="<?php echo e($editandoEstudiante ? route('matricula.estudiantes.actualizar', $editandoEstudiante) : route('matricula.estudiantes.guardar')); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <?php if($editandoEstudiante): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="grid-2">
                    <div class="field">
                        <label for="matricula_nueva">Número de matrícula</label>
                        <input id="matricula_nueva" name="est_matricula" value="<?php echo e(old('est_matricula', $editandoEstudiante->matricula ?? '')); ?>" required>
                        <?php $__errorArgs = ['est_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="field">
                        <label for="pin_nuevo">PIN <?php echo e($editandoEstudiante ? '(opcional)' : ''); ?></label>
                        <input id="pin_nuevo" name="est_pin" type="password" <?php if(! $editandoEstudiante): echo 'required'; endif; ?>>
                        <?php $__errorArgs = ['est_pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label for="nombre">Nombre</label>
                        <input id="nombre" name="nombre" value="<?php echo e(old('nombre', $editandoEstudiante->nombre ?? '')); ?>" required>
                    </div>
                    <div class="field">
                        <label for="apellidos">Apellidos</label>
                        <input id="apellidos" name="apellidos" value="<?php echo e(old('apellidos', $editandoEstudiante->apellidos ?? '')); ?>" required>
                    </div>
                </div>
                <div class="field">
                    <label for="programa">Programa</label>
                    <input id="programa" name="programa" value="<?php echo e(old('programa', $editandoEstudiante->programa ?? '')); ?>" required>
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label for="facultad_est">Facultad</label>
                        <select id="facultad_est" name="facultad" required>
                            <?php $__currentLoopData = ['Ingeniería', 'Ciencias', 'Humanidades']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($opcion); ?>" <?php if(old('facultad', $editandoEstudiante->facultad ?? '') === $opcion): echo 'selected'; endif; ?>><?php echo e($opcion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="field">
                        <label for="semestre">Semestre</label>
                        <input id="semestre" name="semestre" type="number" min="1" max="12" value="<?php echo e(old('semestre', $editandoEstudiante->semestre ?? 1)); ?>" required>
                    </div>
                </div>
                <div class="actions">
                    <?php if($editandoEstudiante): ?>
                        <a class="btn btn-soft" href="<?php echo e(route('matricula.listas.ver', 'estudiantes')); ?>">Cancelar edición</a>
                    <?php endif; ?>
                    <button class="btn btn-ghost" type="submit"><?php echo e($editandoEstudiante ? 'Guardar cambios' : 'Agregar estudiante'); ?></button>
                </div>
            </form>
        </details>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/listas/estudiantes.blade.php ENDPATH**/ ?>