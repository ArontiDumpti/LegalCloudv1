<?php $__env->startSection('title', 'Cursos · Matrícula'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <span class="badge badge-hot">Paso 2</span>
        <h1>Elige tus cursos</h1>
    </div>

    <?php $__errorArgs = ['oferta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-bad"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <form class="card" method="GET" action="<?php echo e(route('matricula.oferta')); ?>" style="margin-bottom:1rem">
        <div class="grid-2">
            <div class="field" style="margin:0">
                <label for="q">Buscar</label>
                <input id="q" name="q" type="search" value="<?php echo e($busqueda); ?>" placeholder="Materia, código o docente">
            </div>
            <div class="field" style="margin:0">
                <label for="facultad">Facultad</label>
                <select id="facultad" name="facultad" onchange="this.form.submit()">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = ['Ingeniería', 'Ciencias', 'Humanidades']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($opcion); ?>" <?php if($facultad === $opcion): echo 'selected'; endif; ?>><?php echo e($opcion); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </form>

    <div class="grid-3">
        <div>
            <?php $__empty_1 = true; $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignatura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="course">
                    <div class="meta">
                        <span class="badge badge-tide"><?php echo e($asignatura->codigo); ?></span>
                        <span><?php echo e($asignatura->creditos); ?> créditos</span>
                        <span>Prerreq. <?php echo e($asignatura->prerrequisito); ?></span>
                    </div>
                    <h3><?php echo e($asignatura->nombre); ?></h3>
                    <?php $__currentLoopData = $asignatura->grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $lleno = $grupo->estaLleno();
                            $elegido = $idsSeleccion->contains($grupo->id);
                            $pct = $grupo->cupo > 0 ? round(($grupo->tomados / $grupo->cupo) * 100) : 0;
                            $docente = $grupo->profesor->nombre ?? $grupo->docente;
                        ?>
                        <div class="group">
                            <div>
                                <strong><?php echo e($grupo->codigo_grupo); ?></strong>
                                <div class="muted"><?php echo e($docente); ?> · <?php echo e($grupo->horario()); ?></div>
                            </div>
                            <div>
                                <div class="seats"><?php echo e($grupo->cuposLibres()); ?> cupos libres</div>
                                <div class="bar <?php echo e($pct >= 90 ? 'is-low' : ''); ?>"><i style="width:<?php echo e($pct); ?>%"></i></div>
                            </div>
                            <form method="POST" action="<?php echo e(route('matricula.seleccionar')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="grupo_id" value="<?php echo e($grupo->id); ?>">
                                <button class="btn <?php echo e($elegido ? 'btn-aqua' : 'btn-ghost'); ?>" type="submit" <?php if($lleno && ! $elegido): echo 'disabled'; endif; ?>>
                                    <?php echo e($lleno && ! $elegido ? 'Sin cupo' : ($elegido ? 'Seleccionado' : 'Seleccionar')); ?>

                                </button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="card muted">No hay cursos con ese criterio.</div>
            <?php endif; ?>
        </div>
        <aside class="card cart">
            <h2 style="margin-top:0">Tu selección</h2>
            <?php if($seleccion->isEmpty()): ?>
                <p class="muted">Elige un grupo para armar tu horario.</p>
            <?php else: ?>
                <ul style="list-style:none;padding:0;margin:0">
                    <?php $__currentLoopData = $seleccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div>
                                <strong><?php echo e($grupo->asignatura->codigo); ?></strong> <?php echo e($grupo->asignatura->nombre); ?><br>
                                <span class="muted"><?php echo e($grupo->codigo_grupo); ?> · <?php echo e($grupo->horario()); ?></span>
                            </div>
                            <form method="POST" action="<?php echo e(route('matricula.quitar')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="grupo_id" value="<?php echo e($grupo->id); ?>">
                                <button class="tiny" type="submit">Quitar</button>
                            </form>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <p style="margin:1rem 0 0">Créditos: <strong><?php echo e($creditos); ?></strong> / <?php echo e($estudiante->creditos_max); ?></p>
            <div class="actions">
                <a class="btn btn-hot <?php echo e($seleccion->isEmpty() ? 'is-off' : ''); ?>" href="<?php echo e($seleccion->isEmpty() ? '#' : route('matricula.prematricula')); ?>">Revisar horario</a>
            </div>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/oferta.blade.php ENDPATH**/ ?>