<?php $__env->startSection('title', 'Horario · Matrícula'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <span class="badge badge-hot">Paso 3</span>
        <h1>Revisa tu horario</h1>
    </div>

    <?php if(count($cruces)): ?>
        <div class="alert alert-bad">
            Hay cruce entre <?php echo e(collect($cruces)->map(fn ($par) => $par[0]->asignatura->codigo.' y '.$par[1]->asignatura->codigo)->join(', ')); ?>.
            Quita uno de esos grupos antes de confirmar.
        </div>
    <?php endif; ?>
    <?php if($excede): ?>
        <div class="alert alert-bad">Llevas <?php echo e($creditos); ?> créditos y el tope es <?php echo e($estudiante->creditos_max); ?>.</div>
    <?php endif; ?>
    <?php if($puedeConfirmar): ?>
        <div class="alert alert-ok">Horario libre y dentro del tope. Puedes confirmar.</div>
    <?php endif; ?>

    <div class="grid-2" style="margin-bottom:1rem">
        <div class="stat"><span class="muted">Asignaturas</span><b><?php echo e($seleccion->count()); ?></b></div>
        <div class="stat"><span class="muted">Créditos</span><b><?php echo e($creditos); ?> / <?php echo e($estudiante->creditos_max); ?></b></div>
    </div>

    <div class="card" style="margin-bottom:1rem">
        <h2 style="margin-top:0">Horario semanal</h2>
        <div class="week">
            <div></div>
            <?php $__currentLoopData = $horario['dias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="head"><?php echo e($dia); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $horario['horas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="hour"><?php echo e($hora); ?></div>
                <?php $__currentLoopData = $horario['dias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $grupo = $horario['celdas'][$hora][$dia] ?? null; ?>
                    <?php if($grupo && $grupo->inicio === $hora): ?>
                        <div class="slot <?php echo e(isset($horario['cruces'][$grupo->id]) ? 'clash' : ''); ?>">
                            <?php echo e($grupo->asignatura->codigo); ?><br><?php echo e($grupo->inicio); ?>–<?php echo e($grupo->fin); ?>

                        </div>
                    <?php elseif($grupo): ?>
                        <div class="slot <?php echo e(isset($horario['cruces'][$grupo->id]) ? 'clash' : ''); ?>"></div>
                    <?php else: ?>
                        <div class="cell"></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card">
        <h2 style="margin-top:0">Resumen</h2>
        <table>
            <thead>
                <tr><th>Código</th><th>Asignatura</th><th>Grupo</th><th>Horario</th><th>Créditos</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $seleccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($grupo->asignatura->codigo); ?></td>
                        <td><?php echo e($grupo->asignatura->nombre); ?></td>
                        <td><?php echo e($grupo->codigo_grupo); ?></td>
                        <td><?php echo e($grupo->horario()); ?></td>
                        <td><?php echo e($grupo->asignatura->creditos); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="actions">
            <form method="POST" action="<?php echo e(route('matricula.cancelar')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-soft" type="submit">Cancelar matrícula</button>
            </form>
            <form method="POST" action="<?php echo e(route('matricula.confirmar')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-hot" type="submit" <?php if(! $puedeConfirmar): echo 'disabled'; endif; ?>>Confirmar matrícula</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/prematricula.blade.php ENDPATH**/ ?>