<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cursos</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <main class="container py-5">
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-4">
                <div>
                    <span class="badge text-bg-secondary mb-2">Listado</span>
                    <h1 class="h2 mb-1">Cursos registrados</h1>
                    <p class="text-secondary mb-0">Estos son los cursos guardados en la base de datos.</p>
                    <a href="<?php echo e(route('personas.index')); ?>" class="small">Ver listado de personas</a>
                </div>
                <a href="<?php echo e(route('cursos.crear')); ?>" class="btn btn-primary">Registrar curso</a>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <?php if($cursos->isEmpty()): ?>
                        <div class="p-4 p-md-5 text-center text-secondary">
                            Aún no hay cursos registrados.
                            <div class="mt-3">
                                <a href="<?php echo e(route('cursos.crear')); ?>" class="btn btn-outline-primary">Añadir el primero</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Instructor</th>
                                        <th scope="col">Duración</th>
                                        <th scope="col">Descripción</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($curso->id); ?></td>
                                            <td><?php echo e($curso->nombre); ?></td>
                                            <td><?php echo e($curso->instructor); ?></td>
                                            <td><?php echo e($curso->duracion_horas); ?> h</td>
                                            <td><?php echo e($curso->descripcion ?: 'No indicada'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\repo\example-app\resources\views/cursos/index.blade.php ENDPATH**/ ?>