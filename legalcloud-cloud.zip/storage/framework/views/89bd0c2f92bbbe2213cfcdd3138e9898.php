<?php $__env->startSection('title', 'Inicio · Matrícula'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <span class="badge badge-hot">Paso 1</span>
        <h1>Matricularse</h1>
        <p class="muted">Ingresa con tu matrícula y PIN para armar el horario del periodo 2026-2.</p>
    </div>

    <?php if (! ($estudiante)): ?>
        <section class="card enroll">
            <div>
                <h2>Ingreso al periodo</h2>
                <p class="muted">Para consultar o actualizar el catálogo, abre las listas y elige cuál quieres ver.</p>
            </div>
            <form method="POST" action="<?php echo e(route('matricula.entrar')); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label for="matricula">Número de matrícula</label>
                    <input id="matricula" name="matricula" value="<?php echo e(old('matricula')); ?>" inputmode="numeric" autocomplete="username" required>
                </div>
                <div class="field">
                    <label for="pin">PIN</label>
                    <input id="pin" name="pin" type="password" autocomplete="current-password" required>
                    <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="err"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="actions">
                    <a class="btn btn-ghost" href="<?php echo e(route('matricula.listas')); ?>">Ver lista</a>
                    <button class="btn btn-hot" type="submit">Ingresar</button>
                </div>
            </form>
        </section>
    <?php else: ?>
        <section class="card enroll">
            <div>
                <span class="badge badge-aqua">Sesión activa</span>
                <h2 style="margin:0.45rem 0 0.2rem"><?php echo e($estudiante->nombreCompleto()); ?></h2>
                <p class="muted"><?php echo e($estudiante->matricula); ?> · <?php echo e($estudiante->programa); ?> · semestre <?php echo e($estudiante->semestre); ?></p>
            </div>
            <div>
                <div class="grid-2">
                    <div class="stat"><span class="muted">Estado</span><b><?php echo e($estudiante->estado); ?></b></div>
                    <div class="stat"><span class="muted">Tope</span><b><?php echo e($estudiante->creditos_max); ?> cr</b></div>
                </div>
                <?php $__currentLoopData = $estudiante->requisitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="req">
                        <span><?php echo e($requisito->nombre); ?></span>
                        <strong class="<?php echo e($requisito->cumple ? 'ok' : 'warn'); ?>"><?php echo e($requisito->cumple ? 'Cumple' : 'Pendiente'); ?></strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="actions">
                    <form method="POST" action="<?php echo e(route('matricula.salir')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-soft" type="submit">Cerrar sesión</button>
                    </form>
                    <a class="btn btn-ghost" href="<?php echo e(route('matricula.listas')); ?>">Ver lista</a>
                    <a class="btn btn-hot" href="<?php echo e(route('matricula.oferta')); ?>">Elegir cursos</a>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/inicio.blade.php ENDPATH**/ ?>