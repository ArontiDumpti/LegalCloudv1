<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Capacitaciones</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <main class="container py-5">
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-4">
                <div>
                    <span class="badge text-bg-secondary mb-2">Capacitación</span>
                    <h1 class="h2 mb-1">Capacitaciones</h1>
                    <p class="text-secondary mb-0">
                        Datos de <?php echo e($persona->nombre); ?> <?php echo e($persona->apellidos); ?>.
                    </p>
                    <a href="<?php echo e(route('personas.index')); ?>" class="small">Volver a personas</a>
                </div>
                <a href="<?php echo e(route('capacitaciones.crear', $persona)); ?>" class="btn btn-primary">Registrar capacitación</a>
            </div>

            <?php if(session('exito')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('exito')); ?>

                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <?php if($capacitaciones->isEmpty()): ?>
                        <div class="p-4 p-md-5 text-center text-secondary">
                            Aún no hay capacitaciones registradas.
                            <div class="mt-3">
                                <a href="<?php echo e(route('capacitaciones.crear', $persona)); ?>" class="btn btn-outline-primary">Añadir la primera</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">Capacitación</th>
                                        <th scope="col">Fecha</th>
                                        <th scope="col">Duración</th>
                                        <th scope="col" class="text-end">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $capacitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capacitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($capacitacion->capacitacion); ?></td>
                                            <td><?php echo e($capacitacion->fecha->format('d/m/Y')); ?></td>
                                            <td><?php echo e($capacitacion->duracion); ?></td>
                                            <td>
                                                <div class="d-flex justify-content-end gap-2">
                                                    <a href="<?php echo e(route('capacitaciones.editar', [$persona, $capacitacion])); ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                                                    <form
                                                        method="POST"
                                                        action="<?php echo e(route('capacitaciones.destroy', [$persona, $capacitacion])); ?>"
                                                        onsubmit="return confirm('¿Eliminar la capacitación <?php echo e($capacitacion->capacitacion); ?>?')"
                                                    >
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-outline-danger">Eliminar</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </body>
</html>
<?php /**PATH C:\repo\example-app\resources\views/capacitaciones/index.blade.php ENDPATH**/ ?>