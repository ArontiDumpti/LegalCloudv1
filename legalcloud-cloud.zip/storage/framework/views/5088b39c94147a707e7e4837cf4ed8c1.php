<?php $__env->startSection('title', 'Ver lista · Matrícula'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <span class="badge badge-tide">Catálogo</span>
        <h1>Ver lista</h1>
        <p class="muted">Elige la lista que quieres consultar. Luego puedes agregar o editar registros.</p>
    </div>

    <div class="picks">
        <a class="card pick" href="<?php echo e(route('matricula.listas.ver', 'estudiantes')); ?>">
            <span class="badge badge-hot">Estudiantes</span>
            <strong><?php echo e($totales['estudiantes']); ?></strong>
            <span class="muted">Quién se matricula</span>
        </a>
        <a class="card pick" href="<?php echo e(route('matricula.listas.ver', 'cursos')); ?>">
            <span class="badge badge-aqua">Cursos</span>
            <strong><?php echo e($totales['cursos']); ?></strong>
            <span class="muted">Oferta y grupos</span>
        </a>
        <a class="card pick" href="<?php echo e(route('matricula.listas.ver', 'docentes')); ?>">
            <span class="badge badge-rose">Docentes</span>
            <strong><?php echo e($totales['docentes']); ?></strong>
            <span class="muted">Quién dicta cada curso</span>
        </a>
    </div>

    <div class="actions" style="justify-content:flex-start">
        <a class="btn btn-soft" href="<?php echo e(route('matricula.inicio')); ?>">Volver a matricularse</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.matricula', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\repo\example-app\resources\views/matricula/listas/menu.blade.php ENDPATH**/ ?>